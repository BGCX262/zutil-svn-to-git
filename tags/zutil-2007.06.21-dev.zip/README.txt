zutil-2007.06.21-dev (development version)

http://code.google.com/p/zutil

A collection of reusable Java components such as:
    * HTML/XML/SQL/URL encoder/decoder
    * Factory Registry implementation
    * Underscore/CamelCase string conversion


You can find more info from the Javadoc documentation (docs/api/index.html)
and from the test code in src/test directory.

This product uses a MIT license (see LICENSE file for details).

Dependencies:
	javassist - used in com.mihaila.zutil.factory package
	testng    - used in com.mihaila.zutil.testng package and in tests

A build script is on the TODO list.